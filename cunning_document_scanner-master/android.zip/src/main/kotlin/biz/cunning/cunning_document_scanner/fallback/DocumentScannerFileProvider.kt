package biz.cunning.cunning_document_scanner.fallback

import androidx.core.content.FileProvider

class DocumentScannerFileProvider: FileProvider() {
}